from django.contrib import admin
from .models import file_upload


admin.site.register(file_upload)
